import React, { useEffect, useState } from 'react'
import './Sidebar.css'
import {Avatar, IconButton} from "@mui/material"
import DonutLargeIcon from '@mui/icons-material/DonutLarge';
import ChatIcon from '@mui/icons-material/Chat';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import SearchOutlined from '@mui/icons-material/SearchOutlined';
import SidebarChat from './SidebarChat';
import { onSnapshot,collection,doc
} from 'firebase/firestore';
import db from './firebase';
import {useStateValue} from './StateProvider'





function Sidebar() {
    const[rooms,setRooms] = useState([]);
    const[{user},dispatch] = useStateValue();
    useEffect(() =>{
       const unsubscribe =  onSnapshot(collection(db,'rooms'),(snapshot) => {
            setRooms(
                snapshot.docs.map((doc) => ({
                    id:doc.id,
                    data:doc.data(),
                }))
            )
        })     
        return () =>{
            unsubscribe();
        }     

    },[]);
    return (
        <div className='sidebar'>
            <div className='sidebar__header'>
                  <Avatar src = {user?.photoURL}/>
                  <div className='sidebar__headerRight'>
                    <IconButton>
                    <DonutLargeIcon/>
                    </IconButton>
                    <IconButton>
                    <MoreVertIcon/> 
                    </IconButton>
                    <IconButton>
                    <ChatIcon/>
                    </IconButton>
                  </div>

            </div>
            <div className='sidebar__search'>
                <div className='side_barsearchContainer'>

                
                   <SearchOutlined/>
                   <input placeholder='Search or start new chat' type="text"></input>
                   </div>

            </div>
            <div className='sidebar__chats'>
                <SidebarChat addNewChat/>
                 {rooms.map(room => (
                    <SidebarChat key = {room.id} id = {room.id} 
                    name = {room.data.name}/>
                ))}

            </div>
          </div>
    )
}

export default Sidebar